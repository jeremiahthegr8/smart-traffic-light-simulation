'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Car,
  ChevronDown,
  CircleHelp,
  Gauge,
  GitBranch,
  Layers3,
  MapPin,
  Pause,
  Play,
  Radio,
  RotateCcw,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Square,
  Terminal,
  Timer,
  Zap,
} from 'lucide-react'

const phases = [
  { name: 'Northbound', color: 'green', duration: '28s', queue: 7 },
  { name: 'Eastbound', color: 'yellow', duration: '08s', queue: 14 },
  { name: 'Southbound', color: 'red', duration: '00s', queue: 22 },
  { name: 'Westbound', color: 'red', duration: '00s', queue: 11 },
]
const chartData = [34, 40, 38, 50, 44, 62, 56, 73, 66, 82, 70, 88]

function SectionTitle({ icon: Icon, eyebrow, title, action }: { icon: typeof Activity; eyebrow: string; title: string; action?: React.ReactNode }) {
  return <div className="section-title"><div className="section-heading"><Icon size={15} /><div><div className="eyebrow">{eyebrow}</div><h2>{title}</h2></div></div>{action}</div>
}

function Signal({ color, label }: { color: 'red' | 'yellow' | 'green'; label: string }) {
  return <div className={`signal signal-${color}`} aria-label={`${label} ${color}`}><span /></div>
}

function Intersection({ active }: { active: number }) {
  return <div className="intersection-wrap"><div className="map-label north">NORTHBOUND <b>07</b></div><div className="map-label east">EASTBOUND <b>14</b></div><div className="map-label south">SOUTHBOUND <b>22</b></div><div className="map-label west">WESTBOUND <b>11</b></div><div className="intersection"><div className="road vertical" /><div className="road horizontal" /><div className="lane-mark lane-v1" /><div className="lane-mark lane-v2" /><div className="lane-mark lane-h1" /><div className="lane-mark lane-h2" /><div className="crosswalk cw-n" /><div className="crosswalk cw-s" /><div className="crosswalk cw-e" /><div className="crosswalk cw-w" /><div className="junction"><span className="junction-core" /><span className="vehicle v1" /><span className="vehicle v2" /><span className="vehicle v3" /></div><div className="signal-box sb-n"><Signal color={active === 0 ? 'green' : 'red'} label="northbound" /></div><div className="signal-box sb-e"><Signal color={active === 1 ? 'green' : 'red'} label="eastbound" /></div><div className="signal-box sb-s"><Signal color={active === 2 ? 'green' : 'red'} label="southbound" /></div><div className="signal-box sb-w"><Signal color={active === 3 ? 'green' : 'red'} label="westbound" /></div></div></div>
}

export default function Page() {
  const [running, setRunning] = useState(true)
  const [active, setActive] = useState(0)
  const [fault, setFault] = useState(false)
  const [mode, setMode] = useState('Adaptive')
  const [tick, setTick] = useState(1248)
  useEffect(() => { if (!running) return; const timer = setInterval(() => { setTick(t => t + 1); setActive(a => (a + (tick % 24 === 0 ? 1 : 0)) % 4) }, 1000); return () => clearInterval(timer) }, [running, tick])
  const status = useMemo(() => fault ? 'Fault detected' : running ? 'Simulation running' : 'Simulation paused', [fault, running])

  return <main className="control-room">
    <header className="topbar"><div className="brand"><div className="brand-mark"><GitBranch size={18} /></div><div><div className="brand-name">SIGNAL<span>LAB</span></div><div className="brand-sub">TRAFFIC CONTROL SYSTEM</div></div></div><div className="top-meta"><span className="live-dot" /> <span className="mono">LOCAL DEMO</span><span className="divider" /><span className="mono">RUN {String(tick).padStart(4, '0')}</span><button className="icon-button" aria-label="Help"><CircleHelp size={17} /></button><button className="icon-button" aria-label="Settings"><Settings2 size={17} /></button></div></header>
    <div className="workspace">
      <aside className="left-rail panel"><SectionTitle icon={SlidersHorizontal} eyebrow="CONFIGURATION" title="Scenario" /><div className="field"><label>Intersection</label><button className="select-like">4-Way / Urban <ChevronDown size={14} /></button></div><div className="field"><label>Control strategy</label><div className="segmented"><button className={mode === 'Fixed' ? 'selected' : ''} onClick={() => setMode('Fixed')}>Fixed</button><button className={mode === 'Adaptive' ? 'selected' : ''} onClick={() => setMode('Adaptive')}>Adaptive</button></div></div><div className="field"><label>Arrival rate <strong>42 veh/min</strong></label><input type="range" defaultValue="42" aria-label="Arrival rate" /></div><div className="field"><label>Cycle length <strong>90 sec</strong></label><input type="range" defaultValue="60" aria-label="Cycle length" /></div><div className="field"><label>Simulation horizon</label><div className="number-input">10 <span>MINUTES</span></div></div><div className="rail-divider" /><div className="field-row"><div><label>Fault injection</label><span className={`status-text ${fault ? 'danger' : ''}`}><span className="status-dot" />{fault ? 'Active' : 'Off'}</span></div><button className={`toggle ${fault ? 'on' : ''}`} onClick={() => setFault(!fault)} aria-label="Toggle fault injection"><span /></button></div><button className="reset-button" onClick={() => { setFault(false); setActive(0); setRunning(false) }}><RotateCcw size={14} /> Reset scenario</button></aside>
      <section className="main-stage"><div className="stage-header"><div><div className="eyebrow">INTERSECTION MONITOR / SIM-04</div><h1>Oak &amp; 5th Avenue</h1><p><MapPin size={13} /> Portland, OR <span className="sep">/</span> Adaptive signal control</p></div><div className="stage-actions"><span className={`run-badge ${fault ? 'fault' : ''}`}><span />{status}</span><button className="primary-button" onClick={() => setRunning(!running)}>{running ? <Pause size={14} /> : <Play size={14} />}{running ? 'Pause run' : 'Resume run'}</button><button className="stop-button" onClick={() => setRunning(false)}><Square size={13} /> Stop</button></div></div><div className="intersection-card"><div className="card-toolbar"><span><Radio size={14} /> LIVE TOPOLOGY</span><span className="mono">T+ 04:12.8</span></div><Intersection active={active} /><div className="phase-strip">{phases.map((phase, i) => <div className={`phase ${i === active ? 'active' : ''}`} key={phase.name}><div className="phase-top"><span className={`phase-indicator ${phase.color}`} />{phase.name}<span className="phase-time">{i === active ? '00:28' : phase.duration}</span></div><div className="queue-bar"><span style={{ width: `${phase.queue * 3.5}%` }} /></div><div className="phase-bottom"><span>QUEUE <b>{phase.queue}</b></span><span>FLOW <b>{i === active ? '34' : '—'} vph</b></span></div></div>)}</div></div><div className="metrics-row"><div className="metric-card"><span>AVG. DELAY</span><strong>18.4 <small>sec</small></strong><em className="positive">−12.8%</em></div><div className="metric-card"><span>THROUGHPUT</span><strong>1,284 <small>vph</small></strong><em className="positive">+8.4%</em></div><div className="metric-card"><span>QUEUE LENGTH</span><strong>54 <small>veh</small></strong><em className="negative">+4.1%</em></div><div className="metric-card"><span>PHASE EFFICIENCY</span><strong>87.2 <small>%</small></strong><em className="positive">+6.7%</em></div></div></section>
      <aside className="right-rail"><div className="telemetry panel"><SectionTitle icon={Activity} eyebrow="LIVE TELEMETRY" title="System health" /><div className="health-score"><div className="score-ring"><strong>98</strong><span>/100</span></div><div><b>Optimal</b><p>All sensors reporting</p></div></div><div className="health-line"><span><span className="status-dot" /> Signal controller</span><b>Connected</b></div><div className="health-line"><span><span className="status-dot" /> Vehicle detection</span><b>12 / 12</b></div><div className="health-line"><span><span className="status-dot" /> Network latency</span><b>24 ms</b></div></div><div className="panel phase-timer"><SectionTitle icon={Timer} eyebrow="CURRENT PHASE" title="Northbound" action={<span className="timer-value">00:28</span>} /><div className="timer-bar"><span /></div><div className="timer-meta"><span>ELAPSED <b>00:22</b></span><span>REMAINING <b>00:28</b></span></div></div><div className="panel quick-stats"><SectionTitle icon={Gauge} eyebrow="PERFORMANCE" title="Quick stats" /><div className="stat-grid"><div><span>VEHICLES</span><b>284</b></div><div><span>COMPLETED</span><b>78</b></div><div><span>AVG SPEED</span><b>24.6</b><small>mph</small></div><div><span>STOPPED</span><b>31</b></div></div></div></aside>
    </div>
    <section className="analysis"><div className="analysis-header"><SectionTitle icon={BarChart3} eyebrow="ANALYSIS WORKSPACE" title="Run performance" action={<div className="tabs"><button className="active">Overview</button><button>Benchmarks</button><button>History</button></div>} /></div><div className="analysis-grid"><div className="chart-panel"><div className="chart-heading"><div><b>Average delay by minute</b><p>Comparing live run against baseline</p></div><div className="legend"><span className="legend-line" /> Adaptive <span className="legend-line baseline" /> Fixed</div></div><div className="chart"><div className="y-labels"><span>60s</span><span>45s</span><span>30s</span><span>15s</span><span>0s</span></div><svg viewBox="0 0 700 210" preserveAspectRatio="none" role="img" aria-label="Average delay chart"><path className="grid-lines" d="M0 20H700 M0 62H700 M0 104H700 M0 146H700 M0 188H700" /><path className="baseline-path" d="M0 130 L64 115 L128 120 L192 96 L256 105 L320 80 L384 87 L448 64 L512 74 L576 50 L640 59 L700 42" /><path className="active-path" d="M0 148 L64 143 L128 150 L192 132 L256 137 L320 115 L384 121 L448 95 L512 105 L576 80 L640 89 L700 70" /></svg></div><div className="x-labels"><span>MIN 01</span><span>03</span><span>05</span><span>07</span><span>09</span><span>10</span></div></div><div className="run-list panel"><SectionTitle icon={Layers3} eyebrow="RECENT RUNS" title="Saved scenarios" action={<button className="text-button">View all</button>} />{['Adaptive / High flow', 'Fixed / Baseline', 'Adaptive / Balanced'].map((run, i) => <div className="run-item" key={run}><div className="run-icon"><Car size={14} /></div><div><b>{run}</b><span>Today, {i + 9}:2{i} AM <em className={i === 1 ? 'neutral' : ''}>{i === 1 ? 'Completed' : 'Completed'}</em></span></div><strong>{i === 1 ? '24.8' : i === 2 ? '19.7' : '18.4'}s</strong></div>)}</div></div></section>
    <footer><span><ShieldCheck size={13} /> Demo mode — results are seeded for exploration</span><span><Terminal size={13} /> API <b>offline</b> <span className="sep">/</span> <Zap size={12} /> WebSocket <b className="ok">ready</b></span></footer>
  </main>
}
